// src/pages/OperatorStations.jsx
import React, { useEffect, useMemo, useState } from "react";
import { stations, stationSlots } from "../api/client";

const cls = (...xs) => xs.filter(Boolean).join(" ");
const toDateInput = (d) => new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate())).toISOString().slice(0,10);

export default function OperatorStations() {
  const [mine, setMine] = useState([]);
  const [sel, setSel] = useState("");
  const [date, setDate] = useState(() => toDateInput(new Date()));
  const [mps, setMps] = useState(60);
  const [slotData, setSlotData] = useState(null);
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState("");

  // load operator's stations
  useEffect(() => {
    (async () => {
      try {
        const res = await stations.mine();
        const arr = Array.isArray(res) ? res : res?.items || [];
        setMine(arr);
        if (!sel && arr.length) setSel(arr[0].id || arr[0].Id);
      } catch (e) {
        setMsg(e.message || "Failed to load your stations.");
      }
    })();
  }, []);

  async function loadSlots() {
    if (!sel) return;
    setBusy(true);
    setMsg("");
    try {
      const res = await stationSlots.list(sel, { date, minutesPerSlot: Number(mps) || 60 });
      setSlotData(res);
    } catch (e) {
      setSlotData(null);
      setMsg(e.message || "Failed to load slots.");
    } finally {
      setBusy(false);
    }
  }
  useEffect(() => { if (sel) loadSlots(); }, [sel, date, mps]);

  const selectedStation = useMemo(
    () => mine.find(s => (s.id||s.Id) === sel),
    [mine, sel]
  );

  return (
    <div className="p-6 max-w-6xl mx-auto space-y-6">
      <header className="flex items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-semibold">My Stations</h2>
          <p className="text-sm text-gray-500">View availability for your assigned stations.</p>
        </div>

        <div className="flex items-center gap-2">
          <div className="hidden md:flex items-center gap-2 text-xs">
            <span className="inline-block h-3 w-3 rounded bg-emerald-400/70 ring-1 ring-emerald-300" />
            Free
            <span className="inline-block h-3 w-3 rounded bg-amber-300/60 ring-1 ring-amber-300 ml-3" />
            Limited
            <span className="inline-block h-3 w-3 rounded bg-rose-300/60 ring-1 ring-rose-300 ml-3" />
            Full
          </div>
        </div>
      </header>

      {msg && (
        <div className="rounded-md border border-amber-200 bg-amber-50 px-3 py-2 text-sm text-amber-900">
          {msg}
        </div>
      )}

      {/* Station pills */}
      <section className="rounded-lg border bg-white p-3">
        {mine.length === 0 ? (
          <div className="text-sm text-gray-500">No stations assigned.</div>
        ) : (
          <div className="flex flex-wrap gap-2">
            {mine.map(s => {
              const id = s.id || s.Id;
              const active = id === sel;
              return (
                <button
                  key={id}
                  onClick={() => setSel(id)}
                  className={cls(
                    "group flex items-center gap-2 rounded-full border px-3 py-1.5 text-sm",
                    active
                      ? "border-gray-900 bg-gray-900 text-white"
                      : "border-gray-200 bg-white hover:bg-gray-50"
                  )}
                >
                  {s.imageUrl && (
                    <img
                      src={s.imageUrl}
                      alt=""
                      className={cls(
                        "h-6 w-6 rounded object-cover ring-1",
                        active ? "ring-white/20" : "ring-gray-200"
                      )}
                    />
                  )}
                  <span className="truncate max-w-[14rem]">
                    {s.name || s.Name}
                  </span>
                  <span className={cls(
                    "ml-1 text-[10px] uppercase tracking-wide",
                    active ? "text-white/70" : "text-gray-500"
                  )}>
                    {s.type || s.Type}
                  </span>
                </button>
              );
            })}
          </div>
        )}
      </section>

      {/* Filters bar */}
      <section className="rounded-lg border bg-white p-3">
        <div className="flex flex-wrap items-end gap-3">
          <div>
            <label className="block text-xs text-gray-600 mb-1">Date</label>
            <input
              type="date"
              className="h-10 rounded border border-gray-300 px-3"
              value={date}
              onChange={(e) => setDate(e.target.value)}
            />
          </div>
          <div>
            <label className="block text-xs text-gray-600 mb-1">Minutes / slot</label>
            <div className="flex items-center gap-2">
              <input
                type="range"
                min={15}
                max={120}
                step={15}
                value={mps}
                onChange={(e)=> setMps(e.target.value)}
                className="w-52"
              />
              <span className="text-sm tabular-nums">{mps}m</span>
            </div>
          </div>
          <button
            onClick={loadSlots}
            disabled={busy}
            className="h-10 rounded bg-gray-900 px-4 text-white disabled:opacity-60"
          >
            {busy ? "Loading…" : "Refresh"}
          </button>

          {selectedStation && (
            <div className="ml-auto text-sm text-gray-600">
              <span className="font-medium">{selectedStation.name || selectedStation.Name}</span>
              <span className="mx-2">•</span>
              Total sockets: <span className="tabular-nums">{selectedStation.totalSlots ?? selectedStation.TotalSlots}</span>
            </div>
          )}
        </div>
      </section>

      {/* Slots */}
      <section className="rounded-lg border bg-white p-4">
        {slotData ? (
          <>
            <div className="mb-3 text-sm text-gray-600">
              Interval: <b>{slotData.minutesPerSlot} min</b> &nbsp;·&nbsp; Max concurrent:{" "}
              <b className="tabular-nums">{slotData.maxConcurrent}</b>
            </div>

            <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
              {slotData.slots.map((sl, i) => {
                const start = new Date(sl.startLocal);
                const end = new Date(sl.endLocal);
                const range = `${start.toLocaleTimeString([], {hour: "2-digit", minute: "2-digit"})} – ${end.toLocaleTimeString([], {hour: "2-digit", minute: "2-digit"})}`;

                const ratio = sl.available / slotData.maxConcurrent;
                const tone =
                  sl.available <= 0
                    ? "bg-rose-100 ring-rose-200"
                    : ratio <= 0.34
                    ? "bg-amber-100 ring-amber-200"
                    : "bg-emerald-100 ring-emerald-200";

                return (
                  <div key={i} className={cls("rounded-lg ring-1 p-3", tone)}>
                    <div className="flex items-center justify-between">
                      <div className="font-medium">{range}</div>
                      <span className={cls(
                        "rounded-full px-2 py-0.5 text-xs ring-1",
                        sl.available <= 0
                          ? "ring-rose-300 text-rose-700 bg-white/60"
                          : "ring-emerald-300 text-emerald-800 bg-white/60"
                      )}>
                        {sl.available <= 0 ? "Full" : "Open"}
                      </span>
                    </div>
                    <div className="mt-1 text-sm">
                      Available: <b className="tabular-nums">{sl.available}</b> / {slotData.maxConcurrent}
                    </div>
                  </div>
                );
              })}
            </div>
          </>
        ) : (
          <div className="text-sm text-gray-500">No slots for the selected date.</div>
        )}
      </section>
    </div>
  );
}
