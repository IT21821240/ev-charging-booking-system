// src/pages/op/OpBookings.jsx
import React, { useEffect, useState } from "react";
import { bookings } from "../api/client";

export default function OpBookings() {
  const [counts, setCounts] = useState({ pending: 0, approved: 0 });
  const [pending, setPending] = useState([]);
  const [approved, setApproved] = useState([]);
  const [msg, setMsg] = useState("");
  const [setBusy] = useState(false);

  async function load() {
    try {
      setBusy(true); setMsg("");
      const [c, p, a] = await Promise.all([
        bookings.operatorCounts(),
        bookings.operatorPending(),
        bookings.operatorApproved()
      ]);
      setCounts({ pending: Number(c?.pending ?? 0), approved: Number(c?.approved ?? 0) });
      setPending(Array.isArray(p) ? p : []);
      setApproved(Array.isArray(a) ? a : []);
    } catch (e) {
      setMsg(e.message || "Failed to load.");
    } finally { setBusy(false); }
  }
  useEffect(() => { load(); const t = setInterval(load, 30000); return () => clearInterval(t); }, []);

  return (
    <div className="p-6 max-w-5xl mx-auto space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-semibold">Operator Bookings</h2>
        <button onClick={load} className="rounded border px-3 py-1.5">Refresh</button>
      </div>
      {msg && <div className="rounded border bg-amber-50 px-3 py-2 text-sm">{msg}</div>}

      <div className="grid grid-cols-2 gap-3">
        <Tile label="Pending approvals" value={counts.pending} />
        <Tile label="Approved (upcoming)" value={counts.approved} />
      </div>

      <List title="Pending approvals" items={pending} empty="No pending bookings." />
      <List title="Approved (upcoming)" items={approved} empty="No approved bookings." />
    </div>
  );
}

function Tile({ label, value }) {
  return (
    <div className="rounded border bg-white p-4">
      <div className="text-sm text-gray-600">{label}</div>
      <div className="mt-1 text-2xl font-semibold">{value}</div>
    </div>
  );
}

function List({ title, items, empty }) {
  return (
    <div className="rounded border bg-white">
      <div className="border-b px-4 py-2 text-sm font-semibold">{title}</div>
      <div className="divide-y">
        {items.length === 0 ? (
          <div className="p-4 text-sm text-gray-500">{empty}</div>
        ) : items.map(b => (
          <div key={b.id || b._id} className="flex items-center justify-between px-4 py-3 text-sm">
            <div>
              <div className="font-medium">
                {b.startTime ? new Date(b.startTime).toLocaleString() : "-"} → {b.endTime ? new Date(b.endTime).toLocaleString() : "-"}
              </div>
              <div className="text-gray-600">Status: {b.status}</div>
            </div>
            <a href="/bookings" className="rounded bg-indigo-600 px-3 py-1.5 text-white">Review</a>
          </div>
        ))}
      </div>
    </div>
  );
}
